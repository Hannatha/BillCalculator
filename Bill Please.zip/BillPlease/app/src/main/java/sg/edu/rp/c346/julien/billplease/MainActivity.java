package sg.edu.rp.c346.julien.billplease;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {
    TextView amountDisplay;
    TextView paxDisplay;
    TextView discountDisplay;
    TextView totalbillDisplay;
    TextView eachpaymentDisplay;
    EditText editAmount;
    EditText editPax;
    EditText editDiscount;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
